// the configured options and settings for Tutorial
#define VERSION_MAJOR 
#define VERSION_MINOR 
